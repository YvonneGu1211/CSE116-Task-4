package app.tests;

import app.gameengine.model.ai.Pathfinding;
import app.gameengine.model.datastructures.LinkedListNode;
import app.gameengine.model.physics.Vector2D;
import static org.junit.Assert.*;
import org.junit.Test;

public class TestTask2 {




    static final double EPSILON = 0.0001;
    private int listSize;

    public static void validatePath(LinkedListNode<Vector2D> linkedList) {
        while (linkedList != null && linkedList.getNext() != null) {
            double xDifference = Math.abs(linkedList.getValue().getX() - linkedList.getNext().getValue().getX());
            double yDifference = Math.abs(linkedList.getValue().getY() - linkedList.getNext().getValue().getY());

            // Ensure movements are along tile boundaries
            assertEquals(0, Math.abs(Math.ceil(linkedList.getValue().getX())) - Math.abs(linkedList.getValue().getX()), EPSILON);
            assertEquals(0, Math.abs(Math.ceil(linkedList.getValue().getY())) - Math.abs(linkedList.getValue().getY()), EPSILON);

            // Ensure movements are valid (either one step in X or one step in Y)
            assertEquals(1, xDifference + yDifference, EPSILON);

            linkedList = linkedList.getNext();
        }
    }

    @Test
    public void findPathTest() {
        Vector2D object1 = new Vector2D(0, 0);
        Vector2D object2 = new Vector2D(1, 1);
        int xDistance = (int) Math.abs(object1.getX() - object2.getX());
        int yDistance = (int) Math.abs(object1.getY() - object2.getY());
        listSize = 1;
        int shortestDistance = xDistance + yDistance;

        Pathfinding Pathfinding = null;
        LinkedListNode<Vector2D> pathLinkedList = Pathfinding.findPath(object1, object2);
        LinkedListNode<Vector2D> tempPathList = pathLinkedList;

        while (tempPathList != null && tempPathList.getNext() != null) {
            listSize++;
            tempPathList = tempPathList.getNext();
        }

        validatePath(pathLinkedList);
        assertEquals(3, listSize);
        assertEquals(shortestDistance, listSize - 1);

        // Test a vertical path
        object1 = new Vector2D(0, 0);
        object2 = new Vector2D(0, 10);
        int xDistance1 = (int) Math.abs(object1.getX() - object2.getX());
        int yDistance2 = (int) Math.abs(object1.getY() - object2.getY());

        listSize = 1;
        shortestDistance = xDistance + yDistance;

        pathLinkedList = Pathfinding.findPath(object1, object2);
        tempPathList = pathLinkedList;

        while (tempPathList != null && tempPathList.getNext() != null) {
            listSize++;
            tempPathList = tempPathList.getNext();
        }

        validatePath(pathLinkedList);
        assertEquals(11, listSize);
        assertEquals(shortestDistance, listSize - 1);

        // Same location path (no movement)
        object1 = new Vector2D(0, 0);
        object2 = new Vector2D(0, 0);
        listSize = 1;
        shortestDistance = 0;

        pathLinkedList = Pathfinding.findPath(object1, object2);
        tempPathList = pathLinkedList;

        while (tempPathList != null && tempPathList.getNext() != null) {
            listSize++;
            tempPathList = tempPathList.getNext();
        }

        validatePath(pathLinkedList);
        assertEquals(1, listSize);
        assertEquals(shortestDistance, listSize - 1);

        // Non-tile-aligned start and end positions
        object1 = new Vector2D(0.5, 0.5);
        object2 = new Vector2D(10.5, 10.5);
        xDistance = Math.abs((int) object1.getX() - (int) object2.getX());
        yDistance = Math.abs((int) object1.getY() - (int) object2.getY());
        listSize = 1;
        shortestDistance = xDistance + yDistance;

        pathLinkedList = Pathfinding.findPath(object1, object2);
        tempPathList = pathLinkedList;

        while (tempPathList != null && tempPathList.getNext() != null) {
            listSize++;
            tempPathList = tempPathList.getNext();
        }

        validatePath(pathLinkedList);
        assertEquals(21, listSize); // Expected based on integer rounding
        assertEquals(shortestDistance, listSize - 1);

        // Null path scenario (out-of-bounds or invalid request)
        object1 = new Vector2D(-100, -100);
        object2 = new Vector2D(100, 100);

        pathLinkedList = Pathfinding.findPath(object1, object2);

        assertNull(pathLinkedList);
    }


}


