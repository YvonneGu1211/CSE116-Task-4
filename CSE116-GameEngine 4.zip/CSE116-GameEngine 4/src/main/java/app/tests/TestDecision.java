package app.tests;

import app.gameengine.Level;
import app.gameengine.model.ai.Decision;

import app.gameengine.model.gameobjects.DynamicGameObject;

public class TestDecision extends Decision {
    private double VelocityX = 0.0;
    private boolean shouldGoLeft = false;

    public TestDecision(String name, boolean shouldGoLeft) {
        super(name);
        this.shouldGoLeft = shouldGoLeft;
    }

    public TestDecision(String name, double VelocityX) {
        super(name);
        this.VelocityX = VelocityX;
    }

    @Override
    public boolean decide(DynamicGameObject obj, Level level, double dt) {
        return this.shouldGoLeft;
    }
    @Override
    public void doAction(DynamicGameObject obj, Level level, double dt){
        obj.getVelocity().setX(this.VelocityX);
    }
}










