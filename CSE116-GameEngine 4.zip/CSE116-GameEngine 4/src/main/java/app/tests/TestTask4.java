package app.tests;
import app.gameengine.model.ai.Decision;
import app.gameengine.model.ai.DecisionTree;
import app.gameengine.model.datastructures.BinaryTreeNode;
import app.gameengine.model.gameobjects.DynamicGameObject;
import app.gameengine.model.gameobjects.Player;
import app.gameengine.model.physics.Vector2D;
import org.junit.Assert;
import org.junit.Test;

import java.util.HashMap;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class TestTask4 {

    double EPSILON = 0.001;


    public static void compareBinaryTreesOfDecisions(BinaryTreeNode<Decision> tree1, BinaryTreeNode<Decision> tree2) {

        if (tree1 == null && tree2 == null) {
            assertTrue(true);
        }
        if (tree1 == null || tree2 == null) {
            assertFalse(false);
        } else {

            assertTrue(tree1.getValue().getName().equals(tree2.getValue().getName()));
            compareBinaryTreesOfDecisions(tree1.getLeft(), tree2.getLeft());
            compareBinaryTreesOfDecisions(tree1.getRight(), tree2.getRight());
        }
    }

    @Test
    public void TestTraverse() {
        HashMap<DecisionTree, DecisionTree> testMap = new HashMap<>();
        DynamicGameObject player = new Player(new Vector2D(0.0, 0.0), 20);
        DecisionTree Tree = new DecisionTree(new BinaryTreeNode<>(new TestDecision("1", true),
                new BinaryTreeNode<>(new TestDecision("2", true),
                        new BinaryTreeNode<>(new TestDecision("3", 0), null, null),
                        new BinaryTreeNode<>(new TestDecision("6", 5), null, null),
                        new BinaryTreeNode<>(new TestDecision("7", 0), null, null);

        Double expectedVelocity = 5.0;
        testMap.put(Tree, expectedVelocity);
    }



    @Test
    public void testReverse(){
        HashMap<DecisionTree, DecisionTree> testMap = new HashMap<>();
        DynamicGameObject player = new Player(new Vector2D(0.0, 0.0), 20);
        DecisionTree Tree = new DecisionTree(new BinaryTreeNode<>(new TestDecision("1", true),
                new BinaryTreeNode<>(new TestDecision("2", true),
                        new BinaryTreeNode<>(new TestDecision("3", true), null, null),
                        new BinaryTreeNode<>(new TestDecision("6", true), null, null),
                        new BinaryTreeNode<>(new TestDecision("7", true), null, null);
                )
        testMap.put(Tree, Tree);






    }

}
