package app.tests;
import app.gameengine.model.ai.Decision;
import app.gameengine.model.ai.DecisionTree;
import app.gameengine.model.datastructures.BinaryTreeNode;
import app.gameengine.model.gameobjects.DynamicGameObject;
import app.gameengine.model.gameobjects.Player;
import app.gameengine.model.physics.Vector2D;
import org.junit.Assert;
import org.junit.Test;

import java.util.HashMap;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class TestTask4 {

    double EPSILON = 0.001;
    Double expectedVelocity = 5.0;


    public static void compareBinaryTreesOfDecisions(BinaryTreeNode<Decision> tree1, BinaryTreeNode<Decision> tree2) {

        if (tree1 == null && tree2 == null) {
            assertTrue(true);
        }
        if (tree1 == null || tree2 == null) {
            assertFalse(false);
        } else {

            assertTrue(tree1.getValue().getName().equals(tree2.getValue().getName()));
            compareBinaryTreesOfDecisions(tree1.getLeft(), tree2.getLeft());
            compareBinaryTreesOfDecisions(tree1.getRight(), tree2.getRight());
        }
    }

    @Test
    public void testTraverse(){
        HashMap<DecisionTree, Double> testMap = new HashMap<>();
        DynamicGameObject player = new Player(new Vector2D(0.0, 0.0), 20);
        DecisionTree Tree = new DecisionTree(new BinaryTreeNode<>(new TestDecision("1", true),
                new BinaryTreeNode<>(new TestDecision("2", true),
                        new BinaryTreeNode<>(new TestDecision("3", 0), null, null),
                        new BinaryTreeNode<>(new TestDecision("4", 0), null, null)),
                        new BinaryTreeNode<>(new TestDecision("5", false),
                                new BinaryTreeNode<>(new TestDecision("6", 10.0), null, null),
                                new BinaryTreeNode<>(new TestDecision("7", 0), null, null))));


        Double expepectedVelocity =10.0;
        testMap.put(Tree,expectedVelocity);


        DecisionTree Tree2 = new DecisionTree(new BinaryTreeNode<>(new TestDecision("1", true),
                new BinaryTreeNode<>(new TestDecision("2", true),
                        new BinaryTreeNode<>(new TestDecision("3", 0), null, null),
                        new BinaryTreeNode<>(new TestDecision("4", 0), null, null)),
                new BinaryTreeNode<>(new TestDecision("5", true),
                        new BinaryTreeNode<>(new TestDecision("6", 0), null, null),
                        new BinaryTreeNode<>(new TestDecision("7", 10.0), null, null))));



        Double expectedVelocity1 = 10.0;
        testMap.put(Tree2,expectedVelocity1);



        DecisionTree Tree3 = new DecisionTree(new BinaryTreeNode<>(new TestDecision("1", false),
                new BinaryTreeNode<>(new TestDecision("2", false),
                        new BinaryTreeNode<>(new TestDecision("3", 0), null, null),
                        new BinaryTreeNode<>(new TestDecision("4", 0), null, null)),
                new BinaryTreeNode<>(new TestDecision("5", false),
                        new BinaryTreeNode<>(new TestDecision("6", 10.0), null, null),
                        new BinaryTreeNode<>(new TestDecision("7", 0), null, null))));


        Double expectedVelocity3 = 10.0;
        testMap.put(Tree,expectedVelocity3);




    }

    @Test
    public void testReverse(){
        HashMap<DecisionTree, DecisionTree> testMap = new HashMap<>();

        DecisionTree Tree = new DecisionTree(new BinaryTreeNode<>(new TestDecision("1", true),
                new BinaryTreeNode<>(new TestDecision("2", true),
                        new BinaryTreeNode<>(new TestDecision("4", true), null, null),
                        new BinaryTreeNode<>(new TestDecision("5", true), null, null)),
                        new BinaryTreeNode<>(new TestDecision("3", true),
                        new BinaryTreeNode<>(new TestDecision("6", true), null, null),
                        new BinaryTreeNode<>(new TestDecision("7", true), null, null))));

        DecisionTree ExpectedTree = new DecisionTree(new BinaryTreeNode<>(new TestDecision("1", true),
                new BinaryTreeNode<>(new TestDecision("3", true),
                        new BinaryTreeNode<>(new TestDecision("7", true), null, null),
                        new BinaryTreeNode<>(new TestDecision("6", true), null, null)),
                new BinaryTreeNode<>(new TestDecision("2", true),
                        new BinaryTreeNode<>(new TestDecision("5", true), null, null),
                        new BinaryTreeNode<>(new TestDecision("4", true), null, null))));








    }

}
