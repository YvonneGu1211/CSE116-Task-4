package app.games.topdownobjects;

import app.gameengine.Level;
import app.gameengine.graphics.SpriteLocation;
import app.gameengine.model.ai.Decision;
import app.gameengine.model.ai.DecisionTree;
import app.gameengine.model.datastructures.BinaryTreeNode;
import app.gameengine.model.datastructures.LinkedListNode;
import app.gameengine.model.gameobjects.DynamicGameObject;
import app.gameengine.model.physics.Vector2D;
import app.gameengine.model.ai.MoveTowardsPlayer;



/**
 * Basic enemy class.
 *
 * In future tasks, you will develop tools to give enemies more features:
 * like pathfinding, AI, etc.
 */
public class Enemy extends DynamicGameObject {
    private LinkedListNode<Vector2D> path;
    private int strength;
    private DecisionTree decisionTree;

    private String name;


    public Enemy(Vector2D location) {
        this(location, 3);
    }

    public Enemy(Vector2D location, int strength) {
        super(location, 10);
        this.strength = strength;
        this.spriteSheetFilename = "Characters/Monsters/Demons/ArmouredRedDemon.png";
        this.defaultSpriteLocation = new SpriteLocation(0, 2);
        this.decisionTree = new DecisionTree(new BinaryTreeNode<>(new MoveTowardsPlayer(name), null, null));
    }







//    }
//
//    public DecisionTree getDecisionTree() {
//        return decisionTree;
//    }
//
//    public void setDecisionTree(DecisionTree decisionTree) {
//        this.decisionTree = decisionTree;
//    }
//
//    public void setPath(LinkedListNode<Vector2D> newPath) {
//        this.path = newPath;
//    }
//
//    public LinkedListNode<Vector2D> getPath() {
//        return this.path;
//    }
//
//    /**
//     * @param dt
//     */
    @Override
    public void updateObject(double dt) {

    }

//    @Override
//    public void update(double dt, Level l) {
//        Vector2D player = l.getPlayer().getLocation();
//
//
//        if (path == null) {
//            path = findPath(this.getLocation(), player);
//
//        } else if (distanceTo(this.getLocation(), path.getValue()) < 0.01) {
//
//            this.getLocation().setX(path.getValue().getX());
//            this.getLocation().setY(path.getValue().getY());
//
//
//            path = path.getNext();
//
//        } else {
//            double xdis= this.getLocation().getX();
//            double ydis=this.getLocation().getY();
//
//            if (Math.abs(this.getLocation().getX()-path.getValue().getX()) > 0.01) {
//
//                if (xdis - path.getValue().getX() > 0) {
//                    this.velocity.setX(-1);
//                    this.velocity.setY(0);
//
//                } else if (ydis - path.getValue().getY() > 0) {
//                    this.velocity.setX(1);
//                    this.velocity.setY(0);
//                }
//            }
//            else{
//
//                if (Math.abs(this.getLocation().getY()-path.getValue().getY())>0.01 ){
//
//                    if (ydis - path.getValue().getY() > 0) {
//                        this.velocity.setX(0);
//                        this.velocity.setY(-1);
//
//                    } else if (ydis - path.getValue().getY() > 0) {
//                        this.velocity.setX(0);
//                        this.velocity.setY(1);
//                    }
//                }
//
//
//            }
//        }
//    }

//    public double distanceTo(Vector2D EnemyCoordinate,Vector2D FinalCoordinate ) {
//        double DistanceX;
//        double DistanecY;
//        double totalX;
//        double totalY;
//        totalX = FinalCoordinate.getX() - EnemyCoordinate.getX();
//        totalY = FinalCoordinate.getY() - EnemyCoordinate.getY();
//        Math.sqrt(totalX*totalX +totalY*totalY );
//
//        return Math.sqrt(totalX*totalX +totalY*totalY );
//    }



    @Override
    public void collideWithDynamicObject(DynamicGameObject otherObject) {
        if (otherObject.isPlayer()) {
            isPlayer();
        }
    }

//    if (otherObject.isPlayer() && isPlayer() <= 0.0) {
//        isPlayer().takeDamage(strength);
//        isPlayer().setInvincibilityFrames(0.5);
//    }

}

//Your method should check if the player has more than 0.0 seconds left
// on their invincibility frames timer (by calling the corresponding getter).
// If so, the method should do nothing. If the player doesn't have any
// invincibility time left, you should have the Player take damage equal
// to the enemy's strength instance, then set the amount of
// invincibility time to 0.5 seconds



