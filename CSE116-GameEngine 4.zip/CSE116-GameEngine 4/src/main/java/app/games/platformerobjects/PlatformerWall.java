package app.games.platformerobjects;

import app.games.commonobjects.Wall;
import app.gameengine.graphics.SpriteLocation;
import app.gameengine.model.gameobjects.DynamicGameObject;

public class PlatformerWall extends Wall {
    double EPSILON = 0.00001;

    public PlatformerWall(int x, int y) {
        super(x, y);
        this.spriteSheetFilename = "Ground/Cliff.png";
        this.defaultSpriteLocation.setColumn(4);
        this.defaultSpriteLocation.setRow(0);
    }

    @Override
    public void collideWithDynamicObject(DynamicGameObject object) {

        super.collideWithDynamicObject(object);

        if (
                        (object.getLocation().getX() > this.getLocation().getX()
                        && object.getLocation().getX()  < this.getLocation().getX() + this.getDimensions().getX())
                ||
                        (object.getLocation().getX() + object.getDimensions().getX() < this.getLocation().getX() + this.getDimensions().getX()
                        && object.getLocation().getX() + object.getDimensions().getX() > this.getLocation().getX())
                ||
                                ((Math.abs(object.getLocation().getX() - this.getLocation().getX()) < EPSILON)
                        && (Math.abs(object.getLocation().getX() + object.getDimensions().getX() - this.getLocation().getX() - this.getDimensions().getX()) < EPSILON))
        ){

            object.getVelocity().setY(0.0);



            if (object.getLocation().getY() < this.getLocation().getY()) {
                object.setOnGround(true);

            }

        }

    }
}



