package app.games.platformerobjects;


import app.gameengine.graphics.SpriteLocation;
import app.gameengine.model.gameobjects.Player;
import app.gameengine.model.gameobjects.StaticGameObject;

import app.gameengine.model.gameobjects.DynamicGameObject;


public class Spike extends StaticGameObject {

    public Spike(int x, int y) {
        super(x,y);
        this.defaultSpriteLocation.setColumn(2);
        this.defaultSpriteLocation.setRow(10);
        spriteSheetFilename = "User Interface/UiIcons.png";
    }

    @Override
    public void collideWithDynamicObject(DynamicGameObject obj) {
        if (obj.isPlayer()) {
            obj.destroy();
        }
    }
}