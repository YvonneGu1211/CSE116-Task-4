package app.gameengine.model.ai;

import app.gameengine.Level;
import app.gameengine.model.gameobjects.DynamicGameObject;
import app.gameengine.model.gameobjects.Player;

public class NearPlayer extends Decision {
    private double Distance;

    public NearPlayer(String name, double acceptableDistance) {
        super(name);
        this.Distance = acceptableDistance;
    }

    @Override
    public boolean decide(DynamicGameObject obj,Level level,double dt) {
        Player player = level.getPlayer();

        double distancex = obj.getLocation().getX() - player.getLocation().getX();
        double distancey = obj.getLocation().getY() - player.getLocation().getY();
        double distance = Math.sqrt(distancex * distancex + distancey * distancey);

        return distance <= Distance;
    }
}
