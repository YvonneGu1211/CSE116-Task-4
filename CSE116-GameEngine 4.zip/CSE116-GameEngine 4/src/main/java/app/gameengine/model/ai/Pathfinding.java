package app.gameengine.model.ai;

import app.gameengine.model.datastructures.LinkedListNode;
import app.gameengine.model.physics.Vector2D;

public class Pathfinding {


    public static LinkedListNode<Vector2D> findPath(Vector2D start, Vector2D end) {


        double startX = Math.floor(start.getX());
        double startY = Math.floor(start.getY());
        double endX = Math.floor(end.getX());
        double endY = Math.floor(end.getY());


        return null;
    }
}
