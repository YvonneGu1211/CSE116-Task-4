package app.gameengine.model.ai;

import app.gameengine.Level;
import app.gameengine.model.gameobjects.DynamicGameObject;
import app.gameengine.model.gameobjects.Player;
import app.gameengine.model.physics.Vector2D;

public class RunAway extends Decision {

    public RunAway(String name) {
        super(name);
    }

    @Override
    public void doAction(DynamicGameObject obj,Level level, double dt) {
        Player player = level.getPlayer();


        Vector2D playerPosition = player.getLocation();


        double dx = obj.getLocation().getX() - playerPosition.getX();
        double dy = obj.getLocation().getY() - playerPosition.getY();
        double distance = Math.sqrt(dx * dx + dy * dy);

        if (distance != 0) {

            double moveX = -dx / distance * obj.getVelocity().getX();
            double moveY = -dy / distance * obj.getVelocity().getY();


            obj.setVelocity(new Vector2D(moveX, moveY));
        }
    }
}