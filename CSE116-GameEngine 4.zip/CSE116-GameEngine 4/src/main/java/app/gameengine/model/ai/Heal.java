package app.gameengine.model.ai;

import app.gameengine.Level;
import app.gameengine.model.gameobjects.DynamicGameObject;
import app.gameengine.model.physics.Vector2D;

public class Heal extends Decision {
    private int healAmount;              // Amount to heal
    private double cooldownTime;         // Cooldown time before healing
    private double timeSpentOnNode = 0;  // Time spent on this node (used to track cooldown)

    public Heal(String name, int healAmount, double cooldownTime) {
        super(name);
        this.healAmount = healAmount;
        this.cooldownTime = cooldownTime;
    }

    //@Override
    public void doAction(Level level, DynamicGameObject obj, double dt) {

        timeSpentOnNode += dt;


        if (timeSpentOnNode >= cooldownTime) {

            int newHealth = obj.getHP() + healAmount;
            obj.setHP(newHealth);

            timeSpentOnNode = 0;


            obj.setVelocity(new Vector2D(0.0, 0.0));


        }
    }
}