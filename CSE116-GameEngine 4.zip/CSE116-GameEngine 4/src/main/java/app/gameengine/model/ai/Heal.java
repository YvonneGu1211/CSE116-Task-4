package app.gameengine.model.ai;

import app.gameengine.Level;
import app.gameengine.model.gameobjects.DynamicGameObject;
import app.gameengine.model.physics.Vector2D;

public class Heal extends Decision {
    private int healAmount;
    private double cooldownTime;
    private double timeSpentOnNode = 0;

    public Heal(String name, int healAmount, double cooldownTime) {
        super(name);
        this.healAmount = healAmount;
        this.cooldownTime = cooldownTime;
    }

    @Override
    public void doAction(DynamicGameObject obj, Level level, double dt) {

        timeSpentOnNode += dt;


        if (timeSpentOnNode >= cooldownTime) {

            int newHealth = obj.getHP() + healAmount;
            obj.setHP(newHealth);

            timeSpentOnNode = 0;


            obj.setVelocity(new Vector2D(0.0, 0.0));


        }
    }
}