package app.gameengine.model.ai;

import app.gameengine.Level;
import app.gameengine.model.gameobjects.DynamicGameObject;
import app.gameengine.model.gameobjects.Player;
import app.gameengine.model.physics.Vector2D;
 public class TargetingPlayer extends Decision {
        private double targetingDistance;

        public TargetingPlayer(String name, double targetingDistance) {
            super(name);
            this.targetingDistance = targetingDistance;
        }

        //@Override
        public boolean decide(Level level, DynamicGameObject obj) {
            Player player = level.getPlayer();


            if (obj.getPath() == null || obj.getPath().getValue() == null) {
                return false;
            }


            Vector2D targetLocation = obj.getPath().getValue();


            double dx = targetLocation.getX() - player.getLocation().getX();
            double dy = targetLocation.getY() - player.getLocation().getY();
            double distance = Math.sqrt(dx * dx + dy * dy);


            return distance <= targetingDistance;
        }
}
