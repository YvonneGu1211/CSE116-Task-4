package app.gameengine.model.ai;



import app.gameengine.Level;

import app.gameengine.model.datastructures.LinkedListNode;
import app.gameengine.model.gameobjects.DynamicGameObject;
import app.gameengine.model.gameobjects.Player;
import app.gameengine.model.physics.Vector2D;
import app.gameengine.model.ai.Pathfinding;
public class MoveTowardsPlayer extends Decision {

        public MoveTowardsPlayer(String name) {
            super(name);
        }

        //@Override
        public void doAction(Level level, DynamicGameObject obj) {
            Player player = level.getPlayer();


            if (obj.getPath() == null || obj.getPath().getValue() == null) {

                //LinkedListNode<Vector2D> newPath = level.findPath(obj.getLocation(), player.getLocation());


                //obj.setPath(newPath);
            }


            if (obj.getPath() != null && obj.getPath().getValue() != null) {

                Vector2D targetPosition = obj.getPath().getValue();


                double dx = targetPosition.getX() - obj.getLocation().getX();
                double dy = targetPosition.getY() - obj.getLocation().getY();
                double distance = Math.sqrt(dx * dx + dy * dy);

                if (distance < 1) {
                    obj.getPath();
                } else {

                    double moveX = dx / distance * obj.getVelocity().getX();
                    double moveY = dy / distance * obj.getVelocity().getY();
                    obj.setLocation(new Vector2D(obj.getLocation().getX() + moveX, obj.getLocation().getY() + moveY));
                }
            }
        }
    }
