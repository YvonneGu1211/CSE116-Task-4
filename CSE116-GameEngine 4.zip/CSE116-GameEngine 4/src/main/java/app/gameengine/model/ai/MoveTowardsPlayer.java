package app.gameengine.model.ai;



import app.gameengine.Level;

import app.gameengine.model.datastructures.LinkedListNode;
import app.gameengine.model.gameobjects.DynamicGameObject;
import app.gameengine.model.gameobjects.Player;
import app.gameengine.model.physics.Vector2D;
import static app.gameengine.model.ai.Pathfinding.findPath;

public class MoveTowardsPlayer extends Decision {

    private LinkedListNode<Vector2D> path;

    public MoveTowardsPlayer(String name) {
        super(name);
    }


    @Override
    public void doAction(DynamicGameObject obj, Level level, double dt) {
        Player player = level.getPlayer();


        if (obj.getPath() == null || obj.getPath().getValue() == null) {

            LinkedListNode<Vector2D> newPath = Pathfinding.findPath(obj.getLocation(), player.getLocation());

            obj.setPath(newPath);
        }


        if (obj.getPath() != null && obj.getPath().getValue() != null) {

            Vector2D targetPosition = obj.getPath().getValue();


            double dx = targetPosition.getX() - obj.getLocation().getX();
            double dy = targetPosition.getY() - obj.getLocation().getY();
            double distance = Math.sqrt(dx * dx + dy * dy);

            if (distance < 1) {
                obj.getPath();
            } else {

                double moveX = dx / distance * obj.getVelocity().getX();
                double moveY = dy / distance * obj.getVelocity().getY();
                obj.setLocation(new Vector2D(obj.getLocation().getX() + moveX, obj.getLocation().getY() + moveY));
            }

        }


        if (path == null) {
            path = findPath(obj.getLocation(), Level.player);

        } else if (distanceTo(obj.getLocation(), path.getValue()) < 0.01) {

            obj.getLocation().setX(path.getValue().getX());
            obj.getLocation().setY(path.getValue().getY());


            path = path.getNext();

        } else {
            double xdis = obj.getLocation().getX();
            double ydis = obj.getLocation().getY();

            if (Math.abs(obj.getLocation().getX() - path.getValue().getX()) > 0.01) {

                if (xdis - path.getValue().getX() > 0) {
                    obj.getVelocity().setX(-1);
                    obj.getVelocity().setY(0);

                } else if (ydis - path.getValue().getY() > 0) {
                    obj.getVelocity().setX(1);
                    obj.getVelocity().setY(0);
                }
            } else {

                if (Math.abs(obj.getLocation().getY() - path.getValue().getY()) > 0.01) {

                    if (ydis - path.getValue().getY() > 0) {
                        obj.getVelocity().setX(0);
                        obj.getVelocity().setY(-1);

                    } else if (ydis - path.getValue().getY() > 0) {
                        obj.getVelocity().setX(0);
                        obj.getVelocity().setY(1);

                    }

                }


            }
        }

    }
    public double distanceTo(Vector2D EnemyCoordinate,Vector2D FinalCoordinate ) {
        double DistanceX;
        double DistanecY;
        double totalX;
        double totalY;
        totalX = FinalCoordinate.getX() - EnemyCoordinate.getX();
        totalY = FinalCoordinate.getY() - EnemyCoordinate.getY();
        Math.sqrt(totalX*totalX +totalY*totalY );

        return Math.sqrt(totalX*totalX +totalY*totalY );
    }

}
