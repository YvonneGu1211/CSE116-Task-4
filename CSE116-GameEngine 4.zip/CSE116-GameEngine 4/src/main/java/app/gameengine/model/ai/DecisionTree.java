package app.gameengine.model.ai;
import app.gameengine.model.datastructures.BinaryTreeNode;
import app.gameengine.model.gameobjects.DynamicGameObject;
import app.gameengine.Level;


public class DecisionTree {
    private BinaryTreeNode<Decision> tree;

    public DecisionTree(BinaryTreeNode<Decision> tree) {
        this.tree = tree;
    }

    public BinaryTreeNode<Decision> getTree() {
        return tree;
    }

    public void setTree(BinaryTreeNode<Decision> tree) {
        this.tree = tree;
    }

    public Decision traverse(BinaryTreeNode<Decision> node, DynamicGameObject gameObject, Level level, double dt) {
        if (node == null) {
            return null;
        }


        if (node.getLeft() == null && node.getRight() == null) {
            return node.getValue();
        }

        Decision currentDecision = node.getValue();
        boolean shouldGoRight = currentDecision.decide(gameObject, level, dt);

        if (shouldGoRight) {
            if (node.getRight() == null) {
                return null;
            }
            return traverse(node.getRight(), gameObject, level, dt);
        } else {
            if (node.getLeft() == null) {
                return null;
            }
            return traverse(node.getLeft(), gameObject, level, dt);
        }
    }

    public void traverse(DynamicGameObject gameObject, Level level, double dt) {
        Decision decision = traverse(tree, gameObject, level, dt);
        if (decision != null) {
            decision.doAction(gameObject, level, dt);
        }
    }

    public void reverse(BinaryTreeNode<Decision> node) {
        if (node == null) {
            return;
        }


        BinaryTreeNode<Decision> temp = node.getLeft();
        node.setLeft(node.getRight());
        node.setRight(temp);


        reverse(node.getLeft());
        reverse(node.getRight());
    }

    public void reverse() {
        reverse(tree);
    }









}

