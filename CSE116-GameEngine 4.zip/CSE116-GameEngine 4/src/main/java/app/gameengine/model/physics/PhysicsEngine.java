package app.gameengine.model.physics;

import app.gameengine.model.gameobjects.DynamicGameObject;
import app.gameengine.Level;
import app.gameengine.model.gameobjects.StaticGameObject;

import java.util.ArrayList;

public class PhysicsEngine {

    public PhysicsEngine() {}

    public void updateLevel(Level level, double dt) {


        for(DynamicGameObject dynamicObject : level.getDynamicObjects()){
            updateObject(dynamicObject, dt);
        }


        for (int i = 0; i < level.getDynamicObjects().size(); i++) {
            DynamicGameObject dynamicObject1 = level.getDynamicObjects().get(i);


            for (int j = i+1; j < level.getDynamicObjects().size(); j++) {
                DynamicGameObject dynamicObject2 = level.getDynamicObjects().get(j);
                if(detectCollision(dynamicObject1.getHitBox(), dynamicObject2.getHitBox())){
                    dynamicObject1.collideWithDynamicObject(dynamicObject2);
                    dynamicObject2.collideWithDynamicObject(dynamicObject1);
                }
            }

            // check for collisions with static objects
            for(StaticGameObject so : level.getStaticObjects()){
                if(detectCollision(so.getHitBox(), dynamicObject1.getHitBox())){
                    so.collideWithDynamicObject(dynamicObject1);
                    dynamicObject1.collideWithStaticObject(so);
                }
            }
        }

    }

    public void updateObject(DynamicGameObject dynamicObject, double dt){
        Vector2D Location = dynamicObject.getLocation();
        Vector2D Velocity = dynamicObject.getVelocity();
        double NewX= Location.getX()+ Velocity.getX()*dt;
        double NewY=Location.getY()+ Velocity.getY()*dt;

        Location.setX(NewX);
        Location.setY(NewY);

    }

    public boolean detectCollision(Hitbox hb1, Hitbox hb2) {
        Vector2D Location1 = hb1.getLocation();
        Vector2D Location2 = hb2.getLocation();
        Vector2D BoxSize1 = hb1.getDimensions();
        Vector2D BoxSize2 = hb2.getDimensions();


        if (Location1.getX() + BoxSize1.getX() < Location2.getX() ||
                Location2.getX() + BoxSize2.getX() < Location1.getX()) {
            return false;
        }


        if (Location1.getY() + BoxSize1.getY() < Location2.getY() ||
                Location2.getY() + BoxSize2.getY() < Location1.getY()) {
            return false;
        }


        return true;
    }

}
