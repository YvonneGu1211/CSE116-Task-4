package app.gameengine.model.ai;

import app.gameengine.Level;
import app.gameengine.model.datastructures.LinkedListNode;
import app.gameengine.model.gameobjects.DynamicGameObject;
import app.gameengine.model.gameobjects.Player;
import app.gameengine.model.physics.Vector2D;

public class RecalculatePath extends Decision {

    public RecalculatePath(String name) {
        super(name);
    }

    @Override
    public void doAction(DynamicGameObject obj,Level level, double dt) {

        obj.setVelocity(new Vector2D(0.0, 0.0));

        Player player = level.getPlayer();


        LinkedListNode<Vector2D> newPath = Pathfinding.findPath(obj.getLocation(), player.getLocation());

        obj.setPath(newPath);
    }
}
