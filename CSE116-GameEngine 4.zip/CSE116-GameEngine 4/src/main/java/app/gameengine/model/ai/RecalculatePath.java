package app.gameengine.model.ai;

import app.gameengine.Level;
import app.gameengine.model.datastructures.LinkedListNode;
import app.gameengine.model.gameobjects.DynamicGameObject;
import app.gameengine.model.gameobjects.Player;
import app.gameengine.model.physics.Vector2D;

public class RecalculatePath extends Decision {

    public RecalculatePath(String name) {
        super(name);
    }

    //@Override
    public void doAction(Level level, DynamicGameObject obj) {

        obj.setVelocity(new Vector2D(0.0, 0.0));

        Player player = level.getPlayer();


        //LinkedListNode<Vector2D> newPath = level.findPath(obj.getLocation(), player.getLocation());

        //obj.setPath(newPath);
    }
}
